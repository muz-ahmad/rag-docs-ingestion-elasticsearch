"""
Utility functions for the RAG w/ WatsonXDiscovery Watson Studio project.
These functions are used by the project's notebooks.

Author: David Sheng
Date: 2024-03-07
Version: 2
"""

import asyncio
import json
import logging
import os
import re
import requests
import tempfile
from functools import wraps
from typing import Any, Dict, List, Optional, Sequence, Callable

import aiohttp
from IPython.display import display, Markdown
from ibm_cloud_sdk_core.authenticators import IAMAuthenticator
from ibm_watson_machine_learning import APIClient
from ibm_watson_machine_learning.foundation_models.model import Model
from ibm_watson_machine_learning.foundation_models.utils.enums import ModelTypes
from llama_index.core import SimpleDirectoryReader
from llama_index.core.callbacks import CallbackManager
from llama_index.core.llms import (
    ChatMessage,
    ChatResponse,
    ChatResponseAsyncGen,
    CompletionResponse,
    CompletionResponseAsyncGen,
    LLMMetadata,
)
from llama_index.core.readers.base import BaseReader
from llama_index.core.schema import Document, NodeWithScore, TextNode
from llama_index.core.types import BaseOutputParser, PydanticProgramMode
from llama_index.core.vector_stores import VectorStoreQuery
from llama_index.core.vector_stores.types import VectorStoreQueryMode
from llama_index.llms.watsonx import WatsonX
from tqdm import tqdm


logger = logging.getLogger(__name__)


def delete_wml_asset_by_name(asset_name: str, wml_client: APIClient) -> str:
    """
    Deletes a Watson Machine Learning asset by name.

    Args:
        asset_name (str): The name of the asset to delete.
        wml_client (APIClient): The Watson Machine Learning client.

    Returns:
        str: The deletion status. Possible values are "DOES NOT EXIST" if the asset does not exist,
        or the deletion status returned by the Watson Machine Learning client.
    """
    existing_wml_assets = {
        asset["metadata"]["name"]: asset["metadata"]["guid"]
        for asset in wml_client.data_assets.get_details()["resources"]
    }
    existing_asset_id_to_delete = existing_wml_assets.get(asset_name)
    if existing_asset_id_to_delete:
        print(f"Deleting existing asset {asset_name}")
        deletion_status = wml_client.data_assets.delete(existing_wml_assets[asset_name])
    else:
        deletion_status = "DOES NOT EXIST"
    return deletion_status


def export_json_to_wml_deployment_space(
    json_data: Dict[str, Any],
    exported_file_name: str,
    wml_client: APIClient,
    space_id=None,
    delete_existing_asset=True,
) -> Dict[str, Any]:
    """
    Export JSON data to Watson Machine Learning deployment space.

    Args:
        json_data (Dict[str, Any]): The JSON data to be exported.
        exported_file_name (str): The name of the exported file.
        wml_client (APIClient): The Watson Machine Learning client.
        space_id (Optional[str]): The ID of the deployment space.
            If provided, the default space will be set to this ID.
        delete_existing_asset (bool): Whether to delete the existing asset
            with the same name before exporting.

    Returns:
        Dict[str, Any]: The details of the exported asset.

    """
    if space_id:
        wml_client.set.default_space(space_id)

    if delete_existing_asset:
        _ = delete_wml_asset_by_name(exported_file_name, wml_client)

    with tempfile.NamedTemporaryFile(suffix=".json", mode="w", delete=False) as tempf:
        json.dump(json_data, tempf)
        tempf.flush()
        asset_details = wml_client.data_assets.create(exported_file_name, tempf.name)
    os.remove(tempf.name)

    return asset_details


def format_scoring_input(question: str) -> Dict[str, Any]:
    """
    Formats the input question for a Watson Machine Learning scoring request

    Args:
        question (str): The input question to be formatted.

    Returns:
        dict: The formatted payload for scoring.

    """
    payload = {"input_data": [{"fields": ["Text"], "values": [[question]]}]}
    return payload


def create_sparse_vector_query_with_model(
    model_id: str, model_text_field: str = "ml.tokens"
) -> Callable[[Dict, VectorStoreQuery], Dict]:
    """
    Creates a sparse vector query function with a specified model.
    Intended to be passed as a custom_query to the ElasticsearchStore async_add method.

    Args:
        model_id (str): The ID of the model to be used for text expansion.
        model_text_field (str, optional): The field in the model that contains the text.
            Defaults to "ml.tokens".

    Returns:
        Callable[[Dict, VectorStoreQuery], Dict]: A function that takes an existing query
            and a VectorStoreQuery object, and returns a new query with text expansion
            using the specified model.
    """

    def sparse_vector_query(existing_query: Dict, query: VectorStoreQuery) -> Dict:
        new_query = existing_query.copy()
        if query.mode in [VectorStoreQueryMode.SPARSE, VectorStoreQueryMode.HYBRID]:
            new_query["query"] = {
                "text_expansion": {
                    model_text_field: {
                        "model_id": model_id,
                        "model_text": query.query_str,
                    }
                }
            }
        return new_query

    return sparse_vector_query


def display_query_result(
    question: str,
    llm_response: str,
    references: Optional[List[NodeWithScore]] = None,
    evaluations: Optional[Dict[str, bool]] = None,
) -> None:
    """
    Display the query result with question, answer, evaluations, and references.

    Args:
        question (str): The question asked.
        llm_response (str): The answer generated by the model.
        references (Optional[List[NodeWithScore]], optional): List of references with scores.
            Defaults to None.
        evaluations (Optional[Dict[str, bool]], optional): Dictionary of evaluations.
            Defaults to None.
    """
    evaluations_str = ""
    if evaluations:
        for evaluator, result in evaluations.items():
            evaluations_str += f"**{evaluator}**: {result}<br>"

    if references:
        references_table_str = (
            "<table><thead><th>Score</th><th>ID</th><th>Title</th>"
            '<th>Source</th><th style="text-align: center;">Document</th></thead><tbody>'
        )
        for ref in references:
            if not isinstance(ref, NodeWithScore):
                raise ValueError(
                    "Each item in references must be a llama-index NodeWithScore object"
                )
            node: TextNode = ref.node
            references_table_str += (
                f"<tr><td>{ref.score}</td><td>{node.id_}</td>"
                f'<td>{node.metadata.get("file_name", "N/A")}</td>'
                f'<td><a href="{node.metadata.get("url", "N/A")}">link</a></td>'
                f'<td style="text-align: left;">{node.text}</td></tr>'
            )
        references_table_str += "</tbody></table><br><br><hr>"
    else:
        references_table_str = "Documents were not provided"

    display(
        Markdown(
            f"**Question:** {question}<br>"
            f"**Answer:** {llm_response}<br>"
            f"{evaluations_str}<br>"
            f"{references_table_str}"
        )
    )


def display_wml_response(question: str, response: Dict) -> None:
    """
    Display the response from Watson Machine Learning (WML).

    Args:
        question (str): The question asked to WML.
        response (Dict): The response received from WML.

    Returns:
        None
    """
    references: List[Dict] = response.get("references", None)
    evaluations: Dict = response.get("evaluations", None)
    scores = [ref.pop("score", None) for ref in references]
    reference_nodes = (
        [
            NodeWithScore(node=TextNode(**ref), score=score)
            for score, ref in zip(scores, references)
        ]
        if references
        else None
    )
    display_query_result(
        question,
        response["predictions"][0]["llm_response"],
        reference_nodes,
        evaluations,
    )


class CloudObjectStorageReader(BaseReader):
    """
    A class used to interact with IBM Cloud Object Storage.

    This class inherits from the BasePydanticReader base class
    and overrides its methods to work with IBM Cloud Object Storage.

    Compatible with llama-index framework.

    Taken from wxd-setup-and-ingestion repository in skol-assets

    Attributes
    ----------
    bucket_name : str
        The name of the bucket in the cloud storage.
    credentials : dict
        The credentials required to authenticate with the cloud storage.
        It must contain 'apikey' and 'service_instance_id'.
    hostname : str, optional
    """

    def __init__(
        self,
        bucket_name: str,
        credentials: dict,
        hostname: str = "https://s3.us-south.cloud-object-storage.appdomain.cloud",
        file_extractor: Optional[Dict[str, BaseReader]] = None,
        num_files_limit: Optional[int] = None,
    ):
        self.bucket_name = bucket_name
        self.credentials = credentials
        self.hostname = hostname
        self.num_files_limit = num_files_limit
        self.file_extractor = file_extractor
        self._base_url = f"{self.hostname}/{self.bucket_name}"
        self._authenticator = IAMAuthenticator(self.credentials["apikey"])
        if "apikey" in self.credentials and "service_instance_id" in self.credentials:
            self.credentials = credentials
        else:
            raise ValueError(
                "Missing 'apikey' or 'service_instance_id' in credentials."
            )

    @property
    def bearer_token(self):
        if not hasattr(self, "_bearer_token"):
            self._bearer_token = self._authenticator.token_manager.get_token()
        return self._bearer_token

    @property
    def session_headers(self):
        return {
            "ibm-service-instance-id": self.credentials["service_instance_id"],
            "Authorization": f"Bearer {self.bearer_token}",
        }

    @property
    def async_session(self):
        if not hasattr(self, "_async_session"):
            self._async_session = aiohttp.ClientSession(headers=self.session_headers)
        return self._async_session

    @property
    def session(self):
        if not hasattr(self, "_session"):
            self._session = requests.Session()
            self._session.headers.update(self.session_headers)
        return self._session

    def load_data(self, show_progress: bool = False) -> List[Document]:
        return asyncio.get_event_loop().run_until_complete(
            self.aload_data(show_progress)
        )

    async def aload_data(self, show_progress: bool = False) -> List[Document]:

        async def write_file_to_dir(file_name, dir, pbar: Optional[tqdm] = None):
            data = await self.aget_file_data(file_name)
            with open(os.path.join(dir, file_name), "wb") as f:
                f.write(data)
            if pbar is not None:
                pbar.update()
            return data

        file_names = self.list_files()
        with tempfile.TemporaryDirectory() as temp_dir:
            with tqdm(
                total=len(file_names),
                disable=not show_progress,
                desc="Downloading files to temp dir",
            ) as pbar:
                tasks = [
                    write_file_to_dir(file_name, temp_dir, pbar)
                    for file_name in file_names
                ]
                try:
                    await asyncio.gather(*tasks)
                finally:
                    if hasattr(self, "_async_session"):
                        await self._async_session.close()
                        del self._async_session
            reader = SimpleDirectoryReader(
                temp_dir,
                file_extractor=self.file_extractor,
                num_files_limit=self.num_files_limit,
            )
            documents = reader.load_data(show_progress=show_progress)

        return documents

    def list_files(self) -> List[str]:
        """
        Retrieves a list of file names from the COS bucket.

        Returns:
            List[str]: A list of file names from the COS bucket.
        """
        response_text = self.session.get(self._base_url).text
        file_names = re.findall(r"<Key>(.*?)</Key>", response_text)
        return file_names

    async def aget_file_data(self, file_name: str) -> bytes:
        """
        Asynchronously retrieves the content of a file from the COS bucket.

        Args:
            file_name (str): The name of the file.

        Returns:
            bytes: The file data.
        """

        url = f"{self._base_url}/{file_name}"
        async with self.async_session.get(url) as response:
            data = await response.read()
        return data

    def get_file_data(self, file_name: str) -> bytes:
        """
        Retrieves the content of a file from the COS bucket.

        Args:
            file_name (str): The name of the file to retrieve.

        Returns:
            bytes: The content of the file as bytes.

        """
        url = f"{self._base_url}/{file_name}"
        response = self.session.get(url)
        return response.content

    @classmethod
    def from_service_credentials(
        cls,
        bucket: str,
        service_credentials_path: str,
        hostname: str = "https://s3.us-south.cloud-object-storage.appdomain.cloud",
        *,
        num_files_limit: Optional[int] = None,
        file_extractor: Optional[Dict[str, BaseReader]] = None,
    ) -> "CloudObjectStorageReader":
        with open(service_credentials_path, "r") as file:
            cos_auth_dict = json.load(file)
        credentials = {
            "apikey": cos_auth_dict["apikey"],
            "service_instance_id": cos_auth_dict["resource_instance_id"],
        }
        return cls(
            bucket_name=bucket,
            credentials=credentials,
            hostname=hostname,
            num_files_limit=num_files_limit,
            file_extractor=file_extractor,
        )


class CustomWatsonX(WatsonX):
    """
    IBM WatsonX LLM. Wrapper around the existing WatonX LLM module to provide following features:
    1. Support for dynamically updated WatsonX models.
    The supported models are hardcoded in original implementation and are outdated as of 2/19/24.
    2. Implements the Async methods for the WatsonX LLM.
    While not true async methods, the implementation allows it to be used in async context.
    """

    def __init__(
        self,
        credentials: Dict[str, Any],
        model_id: Optional[str] = "ibm/mpt-7b-instruct2",
        validate_model_id: bool = True,
        project_id: Optional[str] = None,
        space_id: Optional[str] = None,
        max_new_tokens: Optional[int] = 512,
        temperature: Optional[float] = 0.1,
        additional_kwargs: Optional[Dict[str, Any]] = None,
        callback_manager: Optional[CallbackManager] = None,
        system_prompt: Optional[str] = None,
        messages_to_prompt: Optional[Callable[[Sequence[ChatMessage]], str]] = None,
        completion_to_prompt: Optional[Callable[[str], str]] = None,
        pydantic_program_mode: PydanticProgramMode = PydanticProgramMode.DEFAULT,
        output_parser: Optional[BaseOutputParser] = None,
    ) -> None:
        if validate_model_id:
            supported_models = [model.value for model in ModelTypes]
            if model_id not in supported_models:
                raise ValueError(
                    f"Model name {model_id} not found in {supported_models}"
                )
        # The WatsonX package is outdated in terms of supported models.
        # This is a dummy model id to bypass the check.
        super().__init__(
            credentials=credentials,
            model_id="ibm/granite-13b-chat-v2",
            project_id=project_id,
            space_id=space_id,
            max_new_tokens=max_new_tokens,
            temperature=temperature,
            additional_kwargs=additional_kwargs,
            callback_manager=callback_manager,
            system_prompt=system_prompt,
            messages_to_prompt=messages_to_prompt,
            completion_to_prompt=completion_to_prompt,
            pydantic_program_mode=pydantic_program_mode,
            output_parser=output_parser,
        )
        # Set the model_id and model_info to the actual model
        self.model_id = model_id
        self._model = Model(
            model_id=model_id,
            credentials=credentials,
            project_id=project_id,
            space_id=space_id,
        )
        self.model_info = self._model.get_details()

    @classmethod
    def class_name(cls) -> str:
        """Get Class Name."""
        return "CustomWatsonX"

    @property
    def metadata(self) -> LLMMetadata:
        return LLMMetadata(
            context_window=self.model_info["model_limits"]["max_sequence_length"],
            num_output=self.max_new_tokens,
            model_name=self.model_id,
        )

    async def acomplete(
        self, prompt: str, formatted: bool = False, **kwargs: Any
    ) -> CompletionResponse:
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(
            None, self.complete, prompt, formatted, **kwargs
        )

    async def achat(
        self, messages: Sequence[ChatMessage], **kwargs: Any
    ) -> ChatResponse:
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, self.chat, messages, **kwargs)

    async def astream_chat(
        self, messages: Sequence[ChatMessage], **kwargs: Any
    ) -> ChatResponseAsyncGen:
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(None, self.stream_chat, messages, **kwargs)

    async def astream_complete(
        self, prompt: str, formatted: bool = False, **kwargs: Any
    ) -> CompletionResponseAsyncGen:
        loop = asyncio.get_event_loop()
        return await loop.run_in_executor(
            None, self.stream_complete, prompt, formatted, **kwargs
        )


class WSLibExtension:
    """
    Utility class for extending the functionality of the Watson Studio project library
    to more easily interact with Prompt Templates and Parameter Sets

    Args:
        wslib (Any): The Watson Studio project access_project_or_space object
    """

    def __init__(self, wslib: Any):
        self.wslib = wslib

    def get_all_assets_by_type(self) -> Dict[str, List[Dict]]:
        asset_types = [
            asset_type["asset_type"]
            for asset_type in self.wslib.assets.list_asset_types()
        ]
        all_assets = {
            asset_type: self.wslib.assets.list_assets(asset_type)
            for asset_type in asset_types
            if len(self.wslib.assets.list_assets(asset_type)) > 0
        }
        return all_assets

    def _get_asset_file_name_in_storage(self, asset_name: str, asset_type: str) -> str:
        asset_file_name_in_storage = self.wslib.assets.list_attachments(
            asset_name, asset_type=asset_type, raw=True
        )[0]["object_key"]
        return asset_file_name_in_storage

    def _infer_asset_type_from_name(self, asset_name: str) -> str:
        all_assets = self.get_all_assets_by_type()
        for asset_type, assets in all_assets.items():
            if asset_name in [asset["name"] for asset in assets]:
                logger.debug("Inferring %s as %s", asset_name, asset_type)
                return asset_type

        logger.warning(
            "Could not infer asset type for %s, inferring asset type as 'data_asset'",
            asset_name,
        )
        return "data_asset"

    def get_asset_data(
        self, asset_name: str, asset_type: Optional[str] = None
    ) -> bytes:
        if asset_type is None:
            asset_type = self._infer_asset_type_from_name(asset_name)
        asset_file_name_in_storage = self._get_asset_file_name_in_storage(
            asset_name, asset_type
        )
        asset_data = self.wslib.storage.fetch_data(asset_file_name_in_storage).read()
        return asset_data

    def get_asset_as_json(
        self, asset_name: str, asset_type: Optional[str] = None
    ) -> Dict[str, Any]:
        if asset_type is None:
            asset_type = self._infer_asset_type_from_name(asset_name)
        asset_data = self.get_asset_data(asset_name=asset_name, asset_type=asset_type)
        asset_json = json.loads(asset_data.decode("utf-8"))
        return asset_json

    def update_asset_json(
        self,
        asset_name: str,
        updated_json: Dict[str, Any],
        asset_type: Optional[str] = None,
    ):
        if asset_type is None:
            asset_type = self._infer_asset_type_from_name(asset_name)
        updated_asset_data = json.dumps(updated_json).encode("utf-8")
        file_name = self._get_asset_file_name_in_storage(asset_name, asset_type)
        response = self.wslib.storage.store_data(
            filename=file_name, data=updated_asset_data, overwrite=True
        )
        return response

    def get_all_parameter_set_values(self) -> Dict[str, Any]:
        parameter_set_names = [
            parameter_set["name"]
            for parameter_set in self.wslib.assets.list_assets("parameter_set")
        ]
        parameter_set_values = [
            {
                param["name"]: param["value"]
                for param in self.wslib.assets.get_asset(
                    parameter_set_name, "parameter_set"
                )["entity"]["parameter_set"]["parameters"]
            }
            for parameter_set_name in parameter_set_names
        ]
        all_paramset_values = dict(
            item
            for param_set_values in parameter_set_values
            for item in param_set_values.items()
        )
        return all_paramset_values
